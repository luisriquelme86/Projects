package es.uam.eps.poo.xml;

import java.io.IOException;
import java.text.ParseException;
import java.util.Iterator;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.filter.ElementFilter;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author Profesores POO
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, JDOMException
    {
        SAXBuilder parser = new SAXBuilder();
        Document doc = parser.build ("datos/tienda.xml");
        Element datos;

        System.out.println("Listado de usuarios:");
        Iterator<Element> usuarios = doc.getDescendants(new ElementFilter("usuario"));
        while(usuarios.hasNext ())
        {
            datos = usuarios.next();
            System.out.println("\t" + datos.getAttribute("dni").getValue() + ": " +
                               datos.getAttribute("nombre").getValue() + " " +
                               datos.getAttribute("apellidos").getValue());
        }

        System.out.println("Listado de artículos:");
        Iterator<Element> articulos = doc.getDescendants(new ElementFilter ("articulo"));
        while(articulos.hasNext ())
        {
            datos = articulos.next ();
            System.out.println("\t" + datos.getAttribute("nombre").getValue() + " (" +
                               datos.getAttribute("tipo").getValue() + ")");
        }
    }
}
